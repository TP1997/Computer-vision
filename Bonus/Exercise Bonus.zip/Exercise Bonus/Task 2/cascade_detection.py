import numpy as np 
from cv2 import cv2

def CascadeDetection(imageFile, cascadeFile1, cascadeFile2):
    
    # Load the image
    image = cv2.imread(imageFile)
    
    # Create a copy of the image
    imageCopy = image.copy()


    # Convert the image from BGR to Grayscale
    # Load the cascades using cv2.CascadeClassifier
    
    ##-your-code-starts-here-##
    haarCascade1 = 0 # replace me
    haarCascade2 = 0 # replace me
    #-your-code-ends-here-##

    # Perform multi-scale face detection for the gray image using detectMultiScale
    
    #-your-code-starts-here-##
    detectedObjects = [] # replace me
    #-your-code-ends-here-##
    
    #  Draw bounding boxes
    for bbox in detectedObjects:
        # Draw the bounding box with cv2.rectangle
        # Save cropped image to crop-variable based on bounding box coordinates 
        #-your-code-starts-here-##
        crop = 0 # replace me
        #-your-code-ends-here-##

        # Perform multi-scale smile detection for cropped image using detectMultiScale
        cropDetectedObjects = [] # replace me
        for bbox2 in cropDetectedObjects:
            # Draw the bounding box with cv2.rectangle
            
            pass # remove this line when you have added something inside the loop
            #-your-code-starts-here-##
        
            #-your-code-ends-here-##
            

    # Display the output

    cv2.imshow("Face and smile detection", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # Return the bounding boxes
    return detectedObjects

smileDetection = CascadeDetection("fallon.jpeg",
                                  "cascades/haarcascade_frontalface_default.xml",
                                  "cascades/haarcascade_smile.xml")