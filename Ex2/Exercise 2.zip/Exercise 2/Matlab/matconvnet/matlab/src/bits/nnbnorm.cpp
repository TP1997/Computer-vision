#ifdef ENABLE_GPU
#error "The file nnbnorm.cu should be compiled instead"
#endif
#include "nnbnorm.cu"
